#pragma once

namespace ets2la_plugin
{
    constexpr const char* VERSION = "1.61.0-up-scoped-read";
    constexpr const char* GAME_VERSION = "1.61.x";
}
