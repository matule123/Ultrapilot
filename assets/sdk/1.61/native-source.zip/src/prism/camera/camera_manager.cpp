#include "up161_guard.hpp"
#include "camera_manager.hpp"

#include "core.hpp"
#include "memory/memory_utils.hpp"
#include "patterns.hpp"

namespace ets2la_plugin::prism
{

    uint64_t camera_manager_u::instance_ptr_address = 0;

    bool camera_manager_u::scan_patterns() { instance_ptr_address = up161::base() + 0x36af830; return true; }

    camera_manager_u* camera_manager_u::get()
    {
        if ( camera_manager_u::instance_ptr_address != 0 )
        {
            return *reinterpret_cast< camera_manager_u** >( camera_manager_u::instance_ptr_address );
        }
        return nullptr;
    }

}
