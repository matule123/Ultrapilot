#include "up161_guard.hpp"
#include "game_traffic.hpp"

#include "core.hpp"
#include "memory/memory_utils.hpp"
#include "patterns.hpp"

namespace ets2la_plugin::prism
{
    uint64_t game_traffic_u::instance_ptr_address = 0;

    bool game_traffic_u::scan_patterns() { instance_ptr_address = up161::base() + 0x36af818; return true; }

    game_traffic_u* game_traffic_u::get()
    {
        if ( game_traffic_u::instance_ptr_address != 0 )
        {
            return *reinterpret_cast< game_traffic_u** >( game_traffic_u::instance_ptr_address );
        }
        return nullptr;
    }
}
