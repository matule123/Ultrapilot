#include "base_ctrl.hpp"
#include "up161_guard.hpp"

#include "core.hpp"
#include "memory/memory_utils.hpp"
#include "patterns.hpp"
#include <stdexcept>

namespace ets2la_plugin::prism
{

    uint64_t base_ctrl_u::instance_ptr_address               = 0;
    uint32_t base_ctrl_u::game_actor_offset                  = 0;
    uint32_t base_ctrl_u::some_nearby_kdop_items_offset      = 0;
    uint32_t base_ctrl_u::some_nearby_non_ai_vehicles_offset = 0;

    bool base_ctrl_u::scan_patterns() {
        if(!up161::image_matches())return false;
        instance_ptr_address = up161::base() + 0x36af7c8;
        game_actor_offset = 0x31b0;
        some_nearby_kdop_items_offset = 0x650;
        some_nearby_non_ai_vehicles_offset = 0x2dc8;
        return true;
    }

    base_ctrl_u* base_ctrl_u::get()
    {
        if ( base_ctrl_u::instance_ptr_address != 0 )
        {
            return *reinterpret_cast< base_ctrl_u** >( base_ctrl_u::instance_ptr_address );
        }
        return nullptr;
    }

    array_dyn_t< class kdop_item_t* >* base_ctrl_u::get_nearby_kdop_items() const
    {
        if ( base_ctrl_u::some_nearby_kdop_items_offset != 0 )
        {
            return reinterpret_cast< array_dyn_t< class kdop_item_t* >* >(
                reinterpret_cast< uint64_t >( this ) + base_ctrl_u::some_nearby_kdop_items_offset
            );
        }
        return nullptr;
    }

    // contains TruckerMP nearby players' trucks and trailers
    // also contains trucks and trailers in menus (background/service center/truck dealer/etc...)
    list_dyn_t< class vehicle_shared_u* >* base_ctrl_u::get_some_nearby_non_ai_vehicles_list() const
    {
        if ( base_ctrl_u::some_nearby_non_ai_vehicles_offset != 0 )
        {
            return reinterpret_cast< list_dyn_t< class vehicle_shared_u* >* >(
                reinterpret_cast< uint64_t >( this ) + base_ctrl_u::some_nearby_non_ai_vehicles_offset
            );
        }

        return nullptr;
    }
}
