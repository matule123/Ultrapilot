#include "up161_guard.hpp"
#include "vehicle_shared.hpp"

#include "core.hpp"
#include "memory/memory_utils.hpp"
#include "patterns.hpp"

namespace ets2la_plugin::prism
{
    uint32_t vehicle_shared_u::steering_angle_offset = 0;

    bool vehicle_shared_u::scan_patterns() { steering_angle_offset = 0x6b8; return true; }

    bool vehicle_shared_u::set_steering_angle(float) { return false; }

    float vehicle_shared_u::get_steering_angle()
    {
        if ( vehicle_shared_u::steering_angle_offset == 0 )
        {
            return 0.0f;
        }

        return *reinterpret_cast< float* >(
            reinterpret_cast< char* >( this ) + vehicle_shared_u::steering_angle_offset
        );
    }
}
