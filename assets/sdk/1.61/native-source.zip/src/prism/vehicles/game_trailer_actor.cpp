#include "up161_guard.hpp"
#include "game_trailer_actor.hpp"

#include "core.hpp"
#include "memory/memory_utils.hpp"
#include "patterns.hpp"

namespace ets2la_plugin::prism
{
    uint32_t game_trailer_actor_u::slave_trailer_offset = 0;

    bool game_trailer_actor_u::scan_patterns() { slave_trailer_offset = 0x1088; return true; }

    game_trailer_actor_u* game_trailer_actor_u::get_slave_trailer()
    {
        if ( game_trailer_actor_u::slave_trailer_offset == 0 )
        {
            return nullptr;
        }

        return *reinterpret_cast< game_trailer_actor_u** >(
            reinterpret_cast< char* >( this ) + game_trailer_actor_u::slave_trailer_offset
        );
    }
}
