#include "up161_guard.hpp"
#include "game_physics_vehicle.hpp"

#include "core.hpp"
#include "memory/memory_utils.hpp"
#include "patterns.hpp"

namespace ets2la_plugin::prism
{
    uint32_t game_physics_vehicle_u::trailer_offset = 0;

    bool game_physics_vehicle_u::scan_patterns() { trailer_offset = 0x15a8; return true; }

    game_trailer_actor_u* game_physics_vehicle_u::get_trailer()
    {
        if ( game_physics_vehicle_u::trailer_offset == 0 )
        {
            return nullptr;
        }

        return *reinterpret_cast< game_trailer_actor_u** >(
            reinterpret_cast< char* >( this ) + game_physics_vehicle_u::trailer_offset
        );
    }
}
