#include "game_actor.hpp"
#include "core.hpp"
#include "memory/memory_utils.hpp"
#include "patterns.hpp"
#include "prism/controllers/base_ctrl.hpp"
#include "prism/input/input_mix.hpp"
#include <stdexcept>

namespace ets2la_plugin::prism
{
    uint32_t game_actor_u::steering_input_offset = 0;
    uint32_t game_actor_u::throttle_input_offset = 0;
    uint32_t game_actor_u::brake_input_offset    = 0;

    bool game_actor_u::scan_patterns() { return true; }

    game_actor_u* game_actor_u::get()
    {
        auto* base_ctrl = prism::base_ctrl_u::get();

        if ( base_ctrl == nullptr || base_ctrl_u::game_actor_offset == 0 )
        {
            return nullptr;
        }

        return *reinterpret_cast< game_actor_u** >(
            reinterpret_cast< char* >( base_ctrl ) + base_ctrl_u::game_actor_offset
        );
    }

    void game_actor_u::set_throttle_input(float) {}

    void game_actor_u::set_brake_input(float) {}
}
