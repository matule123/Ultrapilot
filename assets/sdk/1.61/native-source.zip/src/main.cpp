#if defined( _WIN32 )
#include <Windows.h>
#endif
#include "scssdk.h"
#include <memory>
#include <scssdk_telemetry.h>

#include "./core.hpp"

thread_local std::unique_ptr< ets2la_plugin::CCore > g_core;

SCSAPI_RESULT scs_telemetry_init( const scs_u32_t version, const scs_telemetry_init_params_t* const params )
{
    if(version!=SCS_TELEMETRY_VERSION_1_01 || !params)return SCS_RESULT_unsupported;
    auto* init_params = static_cast< const scs_telemetry_init_params_v101_t* >( params );
    g_core            = std::make_unique< ets2la_plugin::CCore >( init_params );

    if ( !g_core->init() )
    {
        g_core.reset();
        return SCS_RESULT_generic_error;
    }

    return SCS_RESULT_ok;
}

SCSAPI_VOID scs_telemetry_shutdown( void )
{
    if ( g_core != nullptr )
    {
        g_core.reset();
    }
}

#if defined( _WIN32 )
BOOL WINAPI DllMain( HMODULE module, DWORD reason_for_call, LPVOID reserved ) { return TRUE; }
#else
int main( int argc, const char** argv ) { return 0; }
#endif
